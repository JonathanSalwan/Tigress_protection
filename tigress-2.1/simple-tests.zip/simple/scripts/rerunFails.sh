#!/bin/bash

egrep -r '^FAILURE' results | sed 's/:FAILURE//g' > /tmp/fails.txt

/bin/rm -f /tmp/tests.txt
touch /tmp/tests.txt
for f in `cat /tmp/fails.txt`
do
   gawk '/^TESTING/{system("scripts/runTest.sh " $2 " " $3); exit}' $f # >> /tmp/tests.txt
done

#for test in `cat /tmp/tests.txt`
#do
#      echo "TEST='$test'"
#      IFS=" "
#      args=($test)
 #     echo "${args[0]} : ${args[1]}"
#      scripts/runTest.sh ${args[0]} ${args[1]} 
#done
