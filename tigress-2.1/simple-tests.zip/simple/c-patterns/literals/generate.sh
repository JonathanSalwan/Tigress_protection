#!/bin/bash 

/bin/rm -f *.c exe

source "../types.sh"

number=0

##################################################################
# generate C programs
##################################################################
function generate() {
   for_intTypes_and_values_do const1
   for_floatTypes_and_values_do const1
   for_intTypes_do litArray1
   for_floatTypes_do litArray1
   for_intTypes_do litArray2
   for_floatTypes_do litArray2
   for_intTypes_do litArray3
   for_floatTypes_do litArray3
   for_intTypes_do litArray4
   for_floatTypes_do litArray4
   for_intTypes_do litStruct1
   for_floatTypes_do litStruct1
   for_intTypes_do litArrayStruct1
   for_floatTypes_do litArrayStruct1
}

##################################################################
# main()
##################################################################
function main() {
   generate
   execute
}

##################################################################
# run
##################################################################
main
exit 0
